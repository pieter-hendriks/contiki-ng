[INFO: Zoul      ] Zolertia RE-Mote revision B platform
[INFO: SENSORNETS] Leaf started with channel hopping sequence size: 1
[INFO: SENSORNETS] With EB period = 1024 / 128 seconds
[INFO: SENSORNETS] Leaf loop start!
[INFO: SENSORNETS] Leaf waiting for association!
[INFO: SENSORNETS] Leaf packet sent!
[INFO: SENSORNETS] First iteration send_callback. Not recording data.
[INFO: SENSORNETS] Leaf loop start!
[INFO: SENSORNETS] Leaf waiting for association!
[INFO: SENSORNETS] Leaf packet sent!
[INFO: HELPERS   ] ticks = 236001
[INFO: HELPERS   ] seconds = 7
[INFO: HELPERS   ] cpu = 3655
[INFO: HELPERS   ] lpm = 230730
[INFO: HELPERS   ] deep = 1754
[INFO: HELPERS   ] tx = 38
[INFO: HELPERS   ] rx = 233785
[INFO: SENSORNETS] Leaf loop start!
[INFO: SENSORNETS] Leaf waiting for association!
[INFO: SENSORNETS] Leaf packet sent!
[INFO: HELPERS   ] ticks = 208063
[INFO: HELPERS   ] seconds = 6
[INFO: HELPERS   ] cpu = 3255
[INFO: HELPERS   ] lpm = 203067
[INFO: HELPERS   ] deep = 1879
[INFO: HELPERS   ] tx = 38
[INFO: HELPERS   ] rx = 205721
[INFO: SENSORNETS] Leaf loop start!
[INFO: SENSORNETS] Leaf waiting for association!
[INFO: SENSORNETS] Leaf packet sent!
[INFO: HELPERS   ] ticks = 237880
[INFO: HELPERS   ] seconds = 7
[INFO: HELPERS   ] cpu = 3635
[INFO: HELPERS   ] lpm = 232638
[INFO: HELPERS   ] deep = 1745
[INFO: HELPERS   ] tx = 38
[INFO: HELPERS   ] rx = 235672
[INFO: SENSORNETS] Leaf loop start!
[INFO: SENSORNETS] Leaf waiting for association!
[INFO: SENSORNETS] Leaf packet sent!
[INFO: HELPERS   ] ticks = 256231
[INFO: HELPERS   ] seconds = 8
[INFO: HELPERS   ] cpu = 3828
[INFO: HELPERS   ] lpm = 250621
[INFO: HELPERS   ] deep = 1920
[INFO: HELPERS   ] tx = 38
[INFO: HELPERS   ] rx = 253848
[INFO: SENSORNETS] Leaf loop start!
[INFO: SENSORNETS] Leaf waiting for association!
[INFO: SENSORNETS] Leaf packet sent!
[INFO: HELPERS   ] ticks = 458081
[INFO: HELPERS   ] seconds = 14
[INFO: HELPERS   ] cpu = 6987
[INFO: HELPERS   ] lpm = 449449
[INFO: HELPERS   ] deep = 1785
[INFO: HELPERS   ] tx = 38
[INFO: HELPERS   ] rx = 455835
[INFO: SENSORNETS] Leaf loop start!
[INFO: SENSORNETS] Leaf waiting for association!
[INFO: SENSORNETS] Leaf packet sent!
[INFO: HELPERS   ] ticks = 224116
[INFO: HELPERS   ] seconds = 7
[INFO: HELPERS   ] cpu = 3519
[INFO: HELPERS   ] lpm = 218928
[INFO: HELPERS   ] deep = 1807
[INFO: HELPERS   ] tx = 38
[INFO: HELPERS   ] rx = 221846
[INFO: SENSORNETS] Leaf loop start!
[INFO: SENSORNETS] Leaf waiting for association!
[INFO: SENSORNETS] Leaf packet sent!
[INFO: HELPERS   ] ticks = 258523
[INFO: HELPERS   ] seconds = 8
[INFO: HELPERS   ] cpu = 4026
[INFO: HELPERS   ] lpm = 252728
[INFO: HELPERS   ] deep = 1907
[INFO: HELPERS   ] tx = 38
[INFO: HELPERS   ] rx = 256153
[INFO: SENSORNETS] Leaf loop start!
[INFO: SENSORNETS] Leaf waiting for association!
[INFO: SENSORNETS] Leaf packet sent!
[INFO: HELPERS   ] ticks = 217239
[INFO: HELPERS   ] seconds = 7
[INFO: HELPERS   ] cpu = 3404
[INFO: HELPERS   ] lpm = 212134
[INFO: HELPERS   ] deep = 1839
[INFO: HELPERS   ] tx = 38
[INFO: HELPERS   ] rx = 214937
[INFO: SENSORNETS] Leaf loop start!
[INFO: SENSORNETS] Leaf waiting for association!
[INFO: SENSORNETS] Leaf packet sent!
[INFO: HELPERS   ] ticks = 260817
[INFO: HELPERS   ] seconds = 8
[INFO: HELPERS   ] cpu = 3906
[INFO: HELPERS   ] lpm = 255150
[INFO: HELPERS   ] deep = 1899
[INFO: HELPERS   ] tx = 38
[INFO: HELPERS   ] rx = 258455
[INFO: SENSORNETS] Leaf loop start!
[INFO: SENSORNETS] Leaf waiting for association!
[INFO: SENSORNETS] Leaf packet sent!
[INFO: HELPERS   ] ticks = 231000
[INFO: HELPERS   ] seconds = 7
[INFO: HELPERS   ] cpu = 3449
[INFO: HELPERS   ] lpm = 225913
[INFO: HELPERS   ] deep = 1776
[INFO: HELPERS   ] tx = 38
[INFO: HELPERS   ] rx = 228761
[INFO: SENSORNETS] Leaf loop start!
[INFO: SENSORNETS] Leaf waiting for association!
[INFO: SENSORNETS] Leaf packet sent!
[INFO: HELPERS   ] ticks = 237881
[INFO: HELPERS   ] seconds = 7
[INFO: HELPERS   ] cpu = 3695
[INFO: HELPERS   ] lpm = 232579
[INFO: HELPERS   ] deep = 1744
[INFO: HELPERS   ] tx = 38
[INFO: HELPERS   ] rx = 235673
[INFO: SENSORNETS] Leaf loop start!
[INFO: SENSORNETS] Leaf waiting for association!
[INFO: SENSORNETS] Leaf packet sent!
[INFO: HELPERS   ] ticks = 210356
[INFO: HELPERS   ] seconds = 6
[INFO: HELPERS   ] cpu = 3301
[INFO: HELPERS   ] lpm = 205324
[INFO: HELPERS   ] deep = 1870
[INFO: HELPERS   ] tx = 38
[INFO: HELPERS   ] rx = 208025
[INFO: SENSORNETS] Leaf loop start!
[INFO: SENSORNETS] Leaf waiting for association!
[INFO: SENSORNETS] Leaf packet sent!
[INFO: HELPERS   ] ticks = 217236
[INFO: HELPERS   ] seconds = 7
[INFO: HELPERS   ] cpu = 3423
[INFO: HELPERS   ] lpm = 212114
[INFO: HELPERS   ] deep = 1837
[INFO: HELPERS   ] tx = 38
[INFO: HELPERS   ] rx = 214937
[INFO: SENSORNETS] Leaf loop start!
[INFO: SENSORNETS] Leaf waiting for association!
[INFO: SENSORNETS] Leaf packet sent!
[INFO: HELPERS   ] ticks = 263112
[INFO: HELPERS   ] seconds = 8
[INFO: HELPERS   ] cpu = 4016
[INFO: HELPERS   ] lpm = 257346
[INFO: HELPERS   ] deep = 1888
[INFO: HELPERS   ] tx = 38
[INFO: HELPERS   ] rx = 260761
[INFO: SENSORNETS] Leaf loop start!
[INFO: SENSORNETS] Leaf waiting for association!
[INFO: SENSORNETS] Leaf packet sent!
[INFO: HELPERS   ] ticks = 212650
[INFO: HELPERS   ] seconds = 6
[INFO: HELPERS   ] cpu = 3342
[INFO: HELPERS   ] lpm = 207588
[INFO: HELPERS   ] deep = 1858
[INFO: HELPERS   ] tx = 38
[INFO: HELPERS   ] rx = 210330
[INFO: SENSORNETS] Leaf loop start!
[INFO: SENSORNETS] Leaf waiting for association!
[INFO: SENSORNETS] Leaf packet sent!
[INFO: HELPERS   ] ticks = 226412
[INFO: HELPERS   ] seconds = 7
[INFO: HELPERS   ] cpu = 3551
[INFO: HELPERS   ] lpm = 221202
[INFO: HELPERS   ] deep = 1797
[INFO: HELPERS   ] tx = 38
[INFO: HELPERS   ] rx = 224152
[INFO: SENSORNETS] Leaf loop start!
[INFO: SENSORNETS] Leaf waiting for association!
[INFO: SENSORNETS] Leaf packet sent!
[INFO: HELPERS   ] ticks = 205767
[INFO: HELPERS   ] seconds = 6
[INFO: HELPERS   ] cpu = 2942
[INFO: HELPERS   ] lpm = 201075
[INFO: HELPERS   ] deep = 1888
[INFO: HELPERS   ] tx = 38
[INFO: HELPERS   ] rx = 203416
[INFO: SENSORNETS] Leaf loop start!
[INFO: SENSORNETS] Leaf waiting for association!
[INFO: SENSORNETS] Leaf packet sent!
[INFO: HELPERS   ] ticks = 203475
[INFO: HELPERS   ] seconds = 6
[INFO: HELPERS   ] cpu = 3033
[INFO: HELPERS   ] lpm = 198680
[INFO: HELPERS   ] deep = 1900
[INFO: HELPERS   ] tx = 38
[INFO: HELPERS   ] rx = 201112
[INFO: SENSORNETS] Leaf loop start!
[INFO: SENSORNETS] Leaf waiting for association!
[INFO: SENSORNETS] Leaf packet sent!
[INFO: HELPERS   ] ticks = 214943
[INFO: HELPERS   ] seconds = 7
[INFO: HELPERS   ] cpu = 3125
[INFO: HELPERS   ] lpm = 210109
[INFO: HELPERS   ] deep = 1847
[INFO: HELPERS   ] tx = 38
[INFO: HELPERS   ] rx = 212634
[INFO: SENSORNETS] Leaf loop start!
[INFO: SENSORNETS] Leaf waiting for association!
[INFO: SENSORNETS] Leaf packet sent!
[INFO: HELPERS   ] ticks = 210356
[INFO: HELPERS   ] seconds = 6
[INFO: HELPERS   ] cpu = 3266
[INFO: HELPERS   ] lpm = 205359
[INFO: HELPERS   ] deep = 1869
[INFO: HELPERS   ] tx = 38
[INFO: HELPERS   ] rx = 208024
[INFO: SENSORNETS] Leaf loop start!
[INFO: SENSORNETS] Leaf waiting for association!
[INFO: SENSORNETS] Leaf packet sent!
[INFO: HELPERS   ] ticks = 219530
[INFO: HELPERS   ] seconds = 7
[INFO: HELPERS   ] cpu = 3280
[INFO: HELPERS   ] lpm = 214562
[INFO: HELPERS   ] deep = 1826
[INFO: HELPERS   ] tx = 38
[INFO: HELPERS   ] rx = 217241
[INFO: SENSORNETS] Leaf loop start!
[INFO: SENSORNETS] Leaf waiting for association!
[INFO: SENSORNETS] Leaf packet sent!
[INFO: HELPERS   ] ticks = 228706
[INFO: HELPERS   ] seconds = 7
[INFO: HELPERS   ] cpu = 3606
[INFO: HELPERS   ] lpm = 223451
[INFO: HELPERS   ] deep = 1787
[INFO: HELPERS   ] tx = 38
[INFO: HELPERS   ] rx = 226456
[INFO: SENSORNETS] Leaf loop start!
[INFO: SENSORNETS] Leaf waiting for association!
[INFO: SENSORNETS] Leaf packet sent!
[INFO: HELPERS   ] ticks = 205768
[INFO: HELPERS   ] seconds = 6
[INFO: HELPERS   ] cpu = 2942
[INFO: HELPERS   ] lpm = 201076
[INFO: HELPERS   ] deep = 1888
[INFO: HELPERS   ] tx = 38
[INFO: HELPERS   ] rx = 203417
[INFO: SENSORNETS] Leaf loop start!
[INFO: SENSORNETS] Leaf waiting for association!
[INFO: SENSORNETS] Leaf packet sent!
[INFO: HELPERS   ] ticks = 253937
[INFO: HELPERS   ] seconds = 8
[INFO: HELPERS   ] cpu = 4002
[INFO: HELPERS   ] lpm = 248144
[INFO: HELPERS   ] deep = 1929
[INFO: HELPERS   ] tx = 38
[INFO: HELPERS   ] rx = 251545
[INFO: SENSORNETS] Leaf loop start!
[INFO: SENSORNETS] Leaf waiting for association!
[INFO: SENSORNETS] Leaf packet sent!
[INFO: HELPERS   ] ticks = 203474
[INFO: HELPERS   ] seconds = 6
[INFO: HELPERS   ] cpu = 3219
[INFO: HELPERS   ] lpm = 198494
[INFO: HELPERS   ] deep = 1899
[INFO: HELPERS   ] tx = 38
[INFO: HELPERS   ] rx = 201113