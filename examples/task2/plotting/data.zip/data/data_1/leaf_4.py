[INFO: SENSORNETS] Leaf started with channel hopping sequence size: 4
[INFO: SENSORNETS] With EB period = 128 / 128 seconds
[INFO: SENSORNETS] Leaf loop start!
[INFO: SENSORNETS] Leaf waiting for association!
[INFO: SENSORNETS] Leaf packet sent!
[INFO: SENSORNETS] First iteration send_callback. Not recording data.
[INFO: SENSORNETS] Leaf loop start!
[INFO: SENSORNETS] Leaf waiting for association!
[INFO: SENSORNETS] Leaf packet sent!
[INFO: HELPERS   ] ticks = 63970
[INFO: HELPERS   ] seconds = 2
[INFO: HELPERS   ] cpu = 1151
[INFO: HELPERS   ] lpm = 61199
[INFO: HELPERS   ] deep = 1755
[INFO: HELPERS   ] tx = 38
[INFO: HELPERS   ] rx = 61752
[INFO: SENSORNETS] Leaf loop start!
[INFO: SENSORNETS] Leaf waiting for association!
[INFO: SENSORNETS] Leaf packet sent!
[INFO: HELPERS   ] ticks = 81913
[INFO: HELPERS   ] seconds = 2
[INFO: HELPERS   ] cpu = 1365
[INFO: HELPERS   ] lpm = 78754
[INFO: HELPERS   ] deep = 1929
[INFO: HELPERS   ] tx = 38
[INFO: HELPERS   ] rx = 79522
[INFO: SENSORNETS] Leaf loop start!
[INFO: SENSORNETS] Leaf waiting for association!
[INFO: SENSORNETS] Leaf packet sent!
[INFO: HELPERS   ] ticks = 118613
[INFO: HELPERS   ] seconds = 4
[INFO: HELPERS   ] cpu = 1844
[INFO: HELPERS   ] lpm = 115143
[INFO: HELPERS   ] deep = 1764
[INFO: HELPERS   ] tx = 38
[INFO: HELPERS   ] rx = 116387
[INFO: SENSORNETS] Leaf loop start!
[INFO: SENSORNETS] Leaf waiting for association!
[INFO: SENSORNETS] Leaf packet sent!
[INFO: HELPERS   ] ticks = 136956
[INFO: HELPERS   ] seconds = 4
[INFO: HELPERS   ] cpu = 2027
[INFO: HELPERS   ] lpm = 133126
[INFO: HELPERS   ] deep = 1941
[INFO: HELPERS   ] tx = 38
[INFO: HELPERS   ] rx = 134553
[INFO: SENSORNETS] Leaf loop start!
[INFO: SENSORNETS] Leaf waiting for association!
[INFO: SENSORNETS] Leaf packet sent!
[INFO: HELPERS   ] ticks = 58967
[INFO: HELPERS   ] seconds = 2
[INFO: HELPERS   ] cpu = 1090
[INFO: HELPERS   ] lpm = 56237
[INFO: HELPERS   ] deep = 1775
[INFO: HELPERS   ] tx = 38
[INFO: HELPERS   ] rx = 56730
[INFO: SENSORNETS] Leaf loop start!
[INFO: SENSORNETS] Leaf waiting for association!
[INFO: SENSORNETS] Leaf packet sent!
[INFO: HELPERS   ] ticks = 290646
[INFO: HELPERS   ] seconds = 9
[INFO: HELPERS   ] cpu = 4550
[INFO: HELPERS   ] lpm = 284468
[INFO: HELPERS   ] deep = 1765
[INFO: HELPERS   ] tx = 38
[INFO: HELPERS   ] rx = 288418
[INFO: SENSORNETS] Leaf loop start!
[INFO: SENSORNETS] Leaf waiting for association!
[INFO: SENSORNETS] Leaf packet sent!
[INFO: HELPERS   ] ticks = 29149
[INFO: HELPERS   ] seconds = 1
[INFO: HELPERS   ] cpu = 735
[INFO: HELPERS   ] lpm = 26640
[INFO: HELPERS   ] deep = 1909
[INFO: HELPERS   ] tx = 38
[INFO: HELPERS   ] rx = 26777
[INFO: SENSORNETS] Leaf loop start!
[INFO: SENSORNETS] Leaf waiting for association!
[INFO: SENSORNETS] Leaf packet sent!
[INFO: HELPERS   ] ticks = 171374
[INFO: HELPERS   ] seconds = 5
[INFO: HELPERS   ] cpu = 2640
[INFO: HELPERS   ] lpm = 167084
[INFO: HELPERS   ] deep = 1787
[INFO: HELPERS   ] tx = 38
[INFO: HELPERS   ] rx = 169124
[INFO: SENSORNETS] Leaf loop start!
[INFO: SENSORNETS] Leaf waiting for association!
[INFO: SENSORNETS] Leaf packet sent!
[INFO: HELPERS   ] ticks = 81906
[INFO: HELPERS   ] seconds = 2
[INFO: HELPERS   ] cpu = 1359
[INFO: HELPERS   ] lpm = 78752
[INFO: HELPERS   ] deep = 1929
[INFO: HELPERS   ] tx = 38
[INFO: HELPERS   ] rx = 79513
[INFO: SENSORNETS] Leaf loop start!
[INFO: SENSORNETS] Leaf waiting for association!
[INFO: SENSORNETS] Leaf packet sent!
[INFO: HELPERS   ] ticks = 56683
[INFO: HELPERS   ] seconds = 2
[INFO: HELPERS   ] cpu = 1061
[INFO: HELPERS   ] lpm = 53968
[INFO: HELPERS   ] deep = 1788
[INFO: HELPERS   ] tx = 38
[INFO: HELPERS   ] rx = 54432
[INFO: SENSORNETS] Leaf loop start!
[INFO: SENSORNETS] Leaf waiting for association!
[INFO: SENSORNETS] Leaf packet sent!
[INFO: HELPERS   ] ticks = 130084
[INFO: HELPERS   ] seconds = 4
[INFO: HELPERS   ] cpu = 2168
[INFO: HELPERS   ] lpm = 119754
[INFO: HELPERS   ] deep = 8299
[INFO: HELPERS   ] tx = 76
[INFO: HELPERS   ] rx = 121210
[INFO: SENSORNETS] Leaf waiting for association!
[INFO: SENSORNETS] Leaf packet sent!
[INFO: HELPERS   ] ticks = 31858
[INFO: HELPERS   ] seconds = 1
[INFO: HELPERS   ] cpu = 776
[INFO: HELPERS   ] lpm = 27135
[INFO: HELPERS   ] deep = 4081
[INFO: HELPERS   ] tx = 90
[INFO: HELPERS   ] rx = 27237
[INFO: SENSORNETS] Leaf loop start!
[INFO: SENSORNETS] Leaf waiting for association!
[INFO: SENSORNETS] Leaf packet sent!
[INFO: HELPERS   ] ticks = 58978
[INFO: HELPERS   ] seconds = 2
[INFO: HELPERS   ] cpu = 1319
[INFO: HELPERS   ] lpm = 55890
[INFO: HELPERS   ] deep = 1904
[INFO: HELPERS   ] tx = 38
[INFO: HELPERS   ] rx = 56611
[INFO: SENSORNETS] Leaf loop start!
[INFO: SENSORNETS] Leaf waiting for association!
[INFO: SENSORNETS] Leaf packet sent!
[INFO: HELPERS   ] ticks = 240183
[INFO: HELPERS   ] seconds = 7
[INFO: HELPERS   ] cpu = 3683
[INFO: HELPERS   ] lpm = 234903
[INFO: HELPERS   ] deep = 1735
[INFO: HELPERS   ] tx = 38
[INFO: HELPERS   ] rx = 237986
[INFO: SENSORNETS] Leaf loop start!
[INFO: SENSORNETS] Leaf waiting for association!
[INFO: SENSORNETS] Leaf packet sent!
[INFO: HELPERS   ] ticks = 29149
[INFO: HELPERS   ] seconds = 1
[INFO: HELPERS   ] cpu = 734
[INFO: HELPERS   ] lpm = 26641
[INFO: HELPERS   ] deep = 1909
[INFO: HELPERS   ] tx = 38
[INFO: HELPERS   ] rx = 26776
[INFO: SENSORNETS] Leaf loop start!
[INFO: SENSORNETS] Leaf waiting for association!
[INFO: SENSORNETS] Leaf packet sent!
[INFO: HELPERS   ] ticks = 29160
[INFO: HELPERS   ] seconds = 1
[INFO: HELPERS   ] cpu = 752
[INFO: HELPERS   ] lpm = 26634
[INFO: HELPERS   ] deep = 1909
[INFO: HELPERS   ] tx = 38
[INFO: HELPERS   ] rx = 26789
[INFO: SENSORNETS] Leaf loop start!
[INFO: SENSORNETS] Leaf waiting for association!
[INFO: SENSORNETS] Leaf packet sent!
[INFO: HELPERS   ] ticks = 88798
[INFO: HELPERS   ] seconds = 3
[INFO: HELPERS   ] cpu = 1486
[INFO: HELPERS   ] lpm = 85548
[INFO: HELPERS   ] deep = 1898
[INFO: HELPERS   ] tx = 38
[INFO: HELPERS   ] rx = 86437
[INFO: SENSORNETS] Leaf loop start!
[INFO: SENSORNETS] Leaf waiting for association!
[INFO: SENSORNETS] Leaf packet sent!
[INFO: HELPERS   ] ticks = 63566
[INFO: HELPERS   ] seconds = 2
[INFO: HELPERS   ] cpu = 1155
[INFO: HELPERS   ] lpm = 60788
[INFO: HELPERS   ] deep = 1757
[INFO: HELPERS   ] tx = 38
[INFO: HELPERS   ] rx = 61345
[INFO: SENSORNETS] Leaf loop start!
[INFO: SENSORNETS] Leaf waiting for association!
[INFO: SENSORNETS] Leaf packet sent!
[INFO: HELPERS   ] ticks = 29155
[INFO: HELPERS   ] seconds = 1
[INFO: HELPERS   ] cpu = 819
[INFO: HELPERS   ] lpm = 26562
[INFO: HELPERS   ] deep = 1909
[INFO: HELPERS   ] tx = 38
[INFO: HELPERS   ] rx = 26786
[INFO: SENSORNETS] Leaf loop start!
[INFO: SENSORNETS] Leaf waiting for association!
[INFO: SENSORNETS] Leaf packet sent!
[INFO: HELPERS   ] ticks = 150730
[INFO: HELPERS   ] seconds = 5
[INFO: HELPERS   ] cpu = 2272
[INFO: HELPERS   ] lpm = 146716
[INFO: HELPERS   ] deep = 1880
[INFO: HELPERS   ] tx = 38
[INFO: HELPERS   ] rx = 148388
[INFO: SENSORNETS] Leaf loop start!
[INFO: SENSORNETS] Leaf waiting for association!
[INFO: SENSORNETS] Leaf packet sent!
[INFO: HELPERS   ] ticks = 93375
[INFO: HELPERS   ] seconds = 3
[INFO: HELPERS   ] cpu = 1737
[INFO: HELPERS   ] lpm = 89894
[INFO: HELPERS   ] deep = 1878
[INFO: HELPERS   ] tx = 38
[INFO: HELPERS   ] rx = 91033
[INFO: SENSORNETS] Leaf loop start!
[INFO: SENSORNETS] Leaf waiting for association!
[INFO: SENSORNETS] Leaf packet sent!
[INFO: HELPERS   ] ticks = 208070
[INFO: HELPERS   ] seconds = 6
[INFO: HELPERS   ] cpu = 3280
[INFO: HELPERS   ] lpm = 200852
[INFO: HELPERS   ] deep = 4075
[INFO: HELPERS   ] tx = 90
[INFO: HELPERS   ] rx = 203464
[INFO: SENSORNETS] Leaf loop start!
[INFO: SENSORNETS] Leaf waiting for association!
[INFO: SENSORNETS] Leaf packet sent!
[INFO: HELPERS   ] ticks = 29150
[INFO: HELPERS   ] seconds = 1
[INFO: HELPERS   ] cpu = 736
[INFO: HELPERS   ] lpm = 26780
[INFO: HELPERS   ] deep = 1768
[INFO: HELPERS   ] tx = 38
[INFO: HELPERS   ] rx = 26919
[INFO: SENSORNETS] Leaf loop start!
[INFO: SENSORNETS] Leaf waiting for association!
[INFO: SENSORNETS] Leaf packet sent!
[INFO: HELPERS   ] ticks = 120909
[INFO: HELPERS   ] seconds = 4
[INFO: HELPERS   ] cpu = 1927
[INFO: HELPERS   ] lpm = 117365
[INFO: HELPERS   ] deep = 1755
[INFO: HELPERS   ] tx = 38
[INFO: HELPERS   ] rx = 118692
[INFO: SENSORNETS] Leaf loop start!
[INFO: SENSORNETS] Leaf waiting for association!
[INFO: SENSORNETS] Leaf packet sent!
[INFO: HELPERS   ] ticks = 84200
[INFO: HELPERS   ] seconds = 3
[INFO: HELPERS   ] cpu = 1385
[INFO: HELPERS   ] lpm = 81029
[INFO: HELPERS   ] deep = 1920
[INFO: HELPERS   ] tx = 38
[INFO: HELPERS   ] rx = 81816